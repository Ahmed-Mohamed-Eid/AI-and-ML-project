# { Heart Disease Prediction Project - Full Machine Learning Pipeline }

# ==================================================================================================================================================================

# 1. Data Preprocessing :-
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.feature_selection import chi2, SelectKBest, RFE
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans, AgglomerativeClustering
from sklearn.model_selection import GridSearchCV
import joblib
import warnings
warnings.filterwarnings("ignore")
import streamlit as st
import numpy as np
import joblib

# ==================================================================================================================================================================

# 2. Loading the dataset (downloaded from UCI repository and saved as heart_disease.csv) :-

df = pd.read_csv("heart_disease.csv" , header = None , encoding='ISO-8859-1' ) 
colomns = ['age', 'sex', 'cp', 'trestbps', 'chol', 'fbs','restecg', 'thalach', 'exang', 'oldpeak', 'slope', 'ca', 'thal', 'target']
df.columns = colomns

# ==================================================================================================================================================================

# 3. Handling the missing values :-

df.replace("?" , np.nan , inplace=True)
df = df.apply(pd.to_numeric , errors='coerce')
df.dropna(inplace=True)

#==================================================================================================================================================================

# 4. Converting  target to binary classification :-
df[ "target" ] = df[ "target" ].apply(lambda x:1 if x > 0 else 0)

#==================================================================================================================================================================

# 5. split into features and target :-
x = df.drop( "target" , axis=1)
y = df[ "target" ]

#==================================================================================================================================================================

# 6. scaling the features
scalar = StandardScaler()
x_scalar = scalar.fit_transform(x)

#==================================================================================================================================================================

# 7. Dimensionality reduction :-
pca = PCA()
x_pca = pca.fit_transform(x_scalar)

plt.figure(figsize=(8,5))
plt.plot(np.cumsum(pca.explained_variance_ratio_) , color = "purple")
plt.xlabel( " Number of Components ")
plt.ylabel( " Cumulative Explained varience ")
plt.title( " PCA - Explained Variance ")
plt.grid()
plt.show()

pca = PCA(n_components=10)
x_pca = pca.fit_transform(x_scalar)

#==================================================================================================================================================================

# 8. Feature Selection :-
rf = RandomForestClassifier()
rf.fit(x_scalar , y)

feat_importances = pd.Series(rf.feature_importances_ , index=x.columns)
feat_importances.nlargest(10).plot(kind='barh' , color = 'grey')
plt.xlabel( ' Importance score')
plt.ylabel( ' Features')
plt.title( ' Top 10 Feature Importances (using RF) ')
plt.show()

rfe = RFE(LogisticRegression() , n_features_to_select=10)
x_rfe = rfe.fit_transform(x_scalar , y)

chi2_selector = SelectKBest(chi2 , k = 10)
x_chi2 = chi2_selector.fit_transform(abs(x_scalar) , y)

#==================================================================================================================================================================

# 9. Supervised Models :-
x_train , x_test , y_train , y_test = train_test_split (x_scalar , y , train_size=0.2 , random_state=42)
models = {
    " # Logistic Regression " : LogisticRegression(),
    " # Desicion Tree " : DecisionTreeClassifier(),
    " # Random Forest " : RandomForestClassifier(),
    " # SVM " : SVC( probability = True )
}
for name , model in models.items() :
    model.fit( x_train , y_train )
    y_pred = model.predict( x_test ) 
    y_proba = model.predict_proba( x_test )[ : , 1 ]
    print( f" \n {name}performance:- \n ")
    print( " 1) Accuracy = " , accuracy_score(y_test , y_pred))
    print( " 2) Precision = " , precision_score(y_test , y_pred))
    print( " 3) Recall = " , recall_score(y_test , y_pred))
    print( " 4) F1 Score = " , f1_score(y_test , y_pred))
    print( " 5) ROC AUC = " , roc_auc_score(y_test , y_proba) , "\n")

#==================================================================================================================================================================

# 10. Unsupervised Models :-
inertia = []

for k in range ( 1 , 10 ) :
    km = KMeans( n_clusters = k )
    km.fit(x_scalar)
    inertia.append(km.inertia_)

plt.plot( range( 1 , 10 ) , inertia )
plt.xlabel( " k value ")
plt.ylabel( " Inertia ")
plt.title( " Elbow method - Kmeans ")
plt.show()

kmeans = KMeans( n_clusters = 2 )
kmeans_labels = kmeans.fit_predict( x_scalar )

hc = AgglomerativeClustering( n_clusters = 2 )
hc_labels = hc.fit_predict(x_scalar)

#==================================================================================================================================================================

# 11. Hyoerparameter Tuning :-
param_grid = {
    'n_estimators' : [ 50 , 100 , 200] ,
    'max_depth' : [ None , 5 , 10 ]
}

grid = GridSearchCV( RandomForestClassifier() , param_grid , cv = 3 )
grid.fit( x_train , y_train )
print( " # Best Random Forest Model is : " , grid.best_params_)

#==================================================================================================================================================================

# 12. Model Export
joblib.dump(grid.best_estimator_, 'final_model.pkl')

#==================================================================================================================================================================

# 13. Streamlit UI [Bonus] :-
import streamlit as st
import numpy as np
import joblib

# 13.1 Load the saved model :-
model = joblib.load("final_model.pkl")

st.set_page_config(page_title="Heart Disease Prediction", layout="centered")

st.title(" Heart Disease Prediction App")
st.markdown("Enter your health information below:")

# 13.2 User inputs :_
age = st.number_input("Age", 20, 100, step=1)
sex = st.selectbox("Sex (0 = female, 1 = male)", [0, 1])
cp = st.selectbox("Chest Pain Type (0-3)", [0, 1, 2, 3])
trestbps = st.number_input("Resting Blood Pressure", 80, 200, step=1)
chol = st.number_input("Cholesterol Level", 100, 600, step=1)
fbs = st.selectbox("Fasting Blood Sugar > 120? (1 = Yes, 0 = No)", [0, 1])
restecg = st.selectbox("Resting ECG Results (0-2)", [0, 1, 2])
thalach = st.number_input("Max Heart Rate Achieved", 60, 220, step=1)
exang = st.selectbox("Exercise Induced Angina (1 = Yes, 0 = No)", [0, 1])
oldpeak = st.number_input("ST Depression", 0.0, 10.0, step=0.1)
slope = st.selectbox("Slope of ST Segment (0-2)", [0, 1, 2])
ca = st.selectbox("Number of Major Vessels (0-3)", [0, 1, 2, 3])
thal = st.selectbox("Thalassemia (1 = normal, 2 = fixed defect, 3 = reversible)", [1, 2, 3])

# 13.2 Prepare the input for prediction :-
input_data = np.array([[age, sex, cp, trestbps, chol, fbs, restecg, thalach, exang, oldpeak, slope, ca, thal]])

# 13.2 Predict button :-
if st.button("Predict"):
    prediction = model.predict(input_data)
    result = " You may have heart disease." if prediction[0] == 1 else "✅ You are unlikely to have heart disease."
    st.success(result)






